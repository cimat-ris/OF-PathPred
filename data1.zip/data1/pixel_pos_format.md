# Format of pixel_pos.csv file for each dataset

Size of the matrix is numTrajectoryPoints x 4
The first column  contains all the frame numbers

The second column contains all the pedestrian IDs

The third column contains all the x-coordinates

The fourth column contains all the y-coordinates
